<?php
    $site = 8;
    include('./include/header.php');
    echo '
        <script>
            const jsSite = "sponsor";
        </script>
    ';
?>
        <main class="clearfix">
            <div class="main-cont sponsor-main clearfix col8">
                <h1>SPONSOR</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce quis lectus quis sem lacinia nonummy. Proin mollis lorem non dolor. In hac habitasse platea dictumst. Nulla ultrices odio. Donec augue. Phasellus dui. Maecenas facilisis nisl vitae nibh. Proin vel seo est vitae eros pretium dignissim.<br><br> Aliquam aliquam sodales orci. Suspendisse potenti. Nunc adipiscing euismod arcu. Quisque facilisis mattis lacus. Fusce bibendum, velit in venenatis viverra, tellus ligula digniss ut urna.</p>
                <table>
                    <tr>
                        <th><i class="far fa-eye"></i> Visninger</th>
                        <th>Pris per visning</th>
                    </tr>
                    <tr>
                        <td>1.000</td>
                        <td>0,50 kr.</td>
                    </tr>
                    <tr>
                        <td>2.000</td>
                        <td>0,47 kr.</td>
                    </tr>
                    <tr>
                        <td>5.000</td>
                        <td>0,45 kr.</td>
                    </tr>
                    <tr>
                        <td>10.000</td>
                        <td>0,40 kr.</td>
                    </tr>
                    <tr>
                        <td>25.000</td>
                        <td>0,35 kr.</td>
                    </tr>
                    <tr>
                        <td>50.000</td>
                        <td>0,30 kr.</td>
                    </tr>
                </table>
            </div>
            <?php include('./include/aside.php'); ?>
        </main>
        <?php include('./include/footer.php'); ?>