<?php
    $site = 1;
    include('./include/header.php');
?>
<script>
    const jsSite = 'index';
</script>
        <main class="clearfix">
            <div class="main-cont clearfix col8">
                <h1>SENESTE ARTIKER</h1>
                <div class="index-article-inner"></div>
            </div>
            <?php include('./include/aside.php'); ?>
        </main>
        <?php include('./include/footer.php'); ?>