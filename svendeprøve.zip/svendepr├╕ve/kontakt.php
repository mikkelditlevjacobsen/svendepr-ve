<?php
    $site = 6;
    include('./include/header.php');
    echo '
        <script>
            const jsSite = "kontakt";
        </script>
    ';
?>
        <main class="clearfix">
            <div class="main-cont clearfix col8">
                <h1>KONTAKT MAGASINET</h1>
                <div class="border-kontakt clearfix">
                    <div class="first-kontakt col6 kontakt-divs">
                        <h2><i class="fas fa-map-marker-alt"></i> Adresse</h2>
                        <p>Marielundvej 46 E</p>
                        <p>2730 Herlev</p>
                        <p>Denmark</p>
                    </div>
                    <div class="first-kontakt col6 kontakt-divs">
                        <h2>Kontaktoplysninger</h2>
                        <p><i class="fas fa-phone"></i> Telefon: +45 7011 5100</p>
                        <p><i class="fas fa-fax"></i> Fax: +45 4485 8925</p>
                        <p><i class="fas fa-envelope"></i> E-mail: redaktionen@bbbmag.dk</p>
                    </div>
                </div>
                <h2 class="your-comment">Kontaktformular</h2>
                <form id="kontaktForm" name="kontaktForm" action="javascript:void(0)" class="clearfix" onsubmit="kontaktValidation(this)" autocomplete="on" novalidate>
                    <div class="first-input">
                        <p>Dit navn</p>
                        <input type="text" name="name" autocomplete="name">
                    </div>
                    <div class="sec-input">
                        <p>Din e-mailadresse</p>
                        <input type="email" name="email" autocomplete="email">
                    </div>
                    <p>Emne</p>
                    <input type="text" class="emne" name="emne">
                    <p>Din besked</p>
                    <textarea name="besked"></textarea>
                    <p class="ud-wrong-text"></p>
                    <input type="submit" name="go" value="SEND BESKED">
                </form>
            </div>
            <?php include('./include/aside.php'); ?>
        </main>
        <?php include('./include/footer.php'); ?>