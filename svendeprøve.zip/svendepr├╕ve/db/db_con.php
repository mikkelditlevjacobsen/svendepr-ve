<?php
	$conn = mysqli_connect("localhost","root","root","bbb");
    mysqli_set_charset($conn,"utf8");
    $test = 'diudgd';
?>