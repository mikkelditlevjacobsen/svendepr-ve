<?php
    include('../db/db_con.php');
    include('../routes/getArtikelAmount.php');
    echo $getArtikelAmount;
    $conn->close();
?>