<?php
    include('../db/db_con.php');
    $mail = $_POST['mail'];
    $sql = "DELETE FROM `newsletter` WHERE mail = '$mail'";
    if ($conn->query($sql) === TRUE) {
        echo 'true';
    } else {
        echo 'false';
    }
    $conn->close();
?>