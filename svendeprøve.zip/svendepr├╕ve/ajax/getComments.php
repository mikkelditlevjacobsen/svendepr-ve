<?php
    include('../db/db_con.php');
    $id = $_POST['id'];
    include('../routes/getComments.php');
    echo json_encode($getComments);
    $conn->close();
?>