<?php
    include('../db/db_con.php');
    $cat = $_POST['cat'];
    include('../routes/getMostViewed.php');
    echo json_encode($getMostViewed);
    $conn->close();
?>