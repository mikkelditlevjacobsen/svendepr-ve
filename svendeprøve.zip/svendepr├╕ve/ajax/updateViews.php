<?php
    include('../db/db_con.php');
    $id = $_POST['id'];
    $sql = "UPDATE artikler SET _views = _views + 1 WHERE id = $id";
    if ($conn->query($sql) === TRUE) {
        echo 'true';
    } else {
        echo 'false';
    }
    $conn->close();
?>