<?php
    include('../db/db_con.php');
    $cat = $_POST['cat'];
    $offsetNumber = $_POST['offsetNumber'];
    $amountPerSite = $_POST['amountPerSite'];
    $searchQuery = $_POST['searchQuery'];
    include('../routes/getIndex.php');
    echo json_encode($getIndex);
    $conn->close();
?>