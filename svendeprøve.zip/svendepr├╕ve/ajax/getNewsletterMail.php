<?php
    include('../db/db_con.php');
    $mail = $_POST['mail'];
    include('../routes/getNewsletterMail.php');
    if($getNewsletterMail == 0){
        echo 'false';
    }else{
        echo 'true';
    }
    $conn->close();
?>