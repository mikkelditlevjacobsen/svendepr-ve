<?php
    include('../db/db_con.php');
    include('../routes/getRedaktion.php');
    echo json_encode($getRedaktion);    
    $conn->close();    
?>