<?php
    include('../db/db_con.php');
    $name = $_POST['name'];
    $mail = $_POST['mail'];
    $emne = $_POST['emne'];
    $besked = $_POST['besked'];
    include('../routes/getMail.php');
    $to = $getMail;
    $subject = $emne;
    $message = $name . ' har skrevet følgende: ' . $besked;
    $headers = 'From: ' . $mail . "\r\n";
    if(mail($to,$subject,$message,$headers)){
        echo 'true';
    }else{
        echo 'false';
    }
    $conn->close();
?>