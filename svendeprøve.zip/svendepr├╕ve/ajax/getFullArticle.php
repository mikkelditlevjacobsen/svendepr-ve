<?php
    include('../db/db_con.php');
    $id = $_POST['id'];
    include('../routes/getFullArticle.php');
    echo json_encode($getFullArticle);    
    $conn->close();    
?>