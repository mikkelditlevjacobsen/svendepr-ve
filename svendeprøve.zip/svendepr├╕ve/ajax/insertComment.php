<?php
    include('../db/db_con.php');
    $id = $_POST['id'];
    $name = $_POST['name'];
    $mail = $_POST['mail'];
    $comment = $_POST['comment'];
    $sql = "INSERT INTO comments SET name = '$name', mail = '$mail', re_for = $id, _comment = '$comment'";
    if ($conn->query($sql) === TRUE) {
        $sql = "UPDATE artikler SET _comments = _comments + 1 WHERE id = $id";
        if ($conn->query($sql) === TRUE) {
            echo 'true';
        }else{
            echo 'false';
        }
    } else {
        echo 'false';
    }
    $conn->close();
?>