<?php
    include('../db/db_con.php');
    $cat = $_POST['cat'];
    include('../routes/getReklamer.php');
    echo json_encode($getReklamer);
    $conn->close();
?>