<?php
    $site = $_GET['cat'];
    include('./include/header.php');
    if(empty($site)){
        header('Location: /svendeprøve/');
    }else{
        echo '
            <script>
                var artikelCat = "'.$site.'";
                const jsSite = "kategori";
            </script>
        ';
    }
?>
    <main class="clearfix">
        <div class="main-cont clearfix col8">
            <h1><?php if($site == 'bil') echo'BILER'; else if($site == 'bikes') echo"BIKE'S"; else if($site == 'bod') echo'BÅDE'; ?></h1>
            <div class="kategori-inside clearfix"></div>
        </div>
        <?php include('./include/aside.php'); ?>
    </main>
<?php include('./include/footer.php'); ?>