<?php
    $sql = "SELECT content_ar.id, content_ar.count, content_ar.content, content_ar.re_for, types_ar.types FROM content_ar INNER JOIN types_ar ON content_ar.re_type = types_ar.id WHERE content_ar.re_for = $id ORDER BY content_ar.count ASC";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $getRestArticle[] = $row;            
        }
    }
?>