<?php
    $sql = "SELECT mail FROM mail_receiver ORDER BY id ASC LIMIT 1";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $getMail = $row['mail'];
        }
    }
?>