<?php
    if($cat == 'none'){
        $sql = "SELECT ad FROM ads ORDER BY RAND() LIMIT 5";
    }else{
        if($cat == 'bod'){
            $cat = 'båd';
        }
        $sql = "SELECT ads.ad FROM ads INNER JOIN category ON ads.re_type = category.id WHERE category.category = '$cat' ORDER BY RAND() LIMIT 5";
    }
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $getReklamer[] = $row;
        }
    }
?>