<?php
    $sql = "SELECT COUNT(mail) AS amount FROM newsletter WHERE mail = '$mail'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $getNewsletterMail = $row['amount'];
        }
    }
?>