<?php
    $sql = "SELECT name, _added, _comment FROM comments WHERE re_for = $id ORDER BY _added DESC";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $getComments[] = $row;
        }
    }
?>