<?php
    $sql = "SELECT artikler.title, artikler._added, artikler.id, artikler._views, artikler._order, artikler._comments, redaktionen.name, redaktionen.bio, redaktionen.image FROM artikler INNER JOIN redaktionen ON artikler.re_red = redaktionen.id WHERE artikler.id = $id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $getFullArticle[] = $row;            
        }
    }
?>