<?php
    if($cat == 'none'){
        $sql = "SELECT artikler.id, artikler.title, category.category FROM artikler INNER JOIN category ON artikler.re_cat = category.id ORDER BY artikler._views DESC LIMIT 6";
    }else{
        if($cat == 'bod'){
            $cat = 'båd';
        }
        $sql = "SELECT artikler.id, artikler.title, category.category FROM artikler INNER JOIN category ON artikler.re_cat = category.id WHERE category.category = '$cat' ORDER BY artikler._views DESC LIMIT 6";
    }
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $getMostViewed[] = $row;
        }
    }
?>