<?php
    $sql = "SELECT COUNT(*) FROM artikler";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $getArtikelAmount = $row['COUNT(*)'];
        }
    }
?>