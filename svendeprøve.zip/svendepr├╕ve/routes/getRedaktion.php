<?php
    $sql = "SELECT * FROM `redaktionen` WHERE role_type = 2 ORDER BY name DESC";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $getRedaktion[] = $row;
        }
    }
?>