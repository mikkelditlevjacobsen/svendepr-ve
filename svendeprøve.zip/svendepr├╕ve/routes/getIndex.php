<?php
    if($cat == 'none'){
        $sql = "SELECT LEFT(artikler.title, 29) AS title, LEFT(content_ar.content, 201) AS content, artikler._added, artikler.id, artikler._comments, artikler._views, category.category FROM content_ar INNER JOIN artikler ON content_ar.re_for = artikler.id INNER JOIN category ON artikler.re_cat = category.id WHERE content_ar.preview = 1 ORDER BY artikler._added DESC LIMIT 6";
    }else if($cat == 'arkiv'){
        $sql = "SELECT artikler.title, LEFT(content_ar.content, 201) AS content, artikler._added, artikler.id, artikler._comments, artikler._views, category.category FROM content_ar INNER JOIN artikler ON content_ar.re_for = artikler.id INNER JOIN category ON artikler.re_cat = category.id WHERE content_ar.preview = 1 ORDER BY artikler._added DESC LIMIT $amountPerSite OFFSET $offsetNumber";
    }else if($cat  == 'sog'){
        $sql = "SELECT artikler.title, LEFT(content_ar.content, 201) AS content, artikler._added, artikler.id, artikler._comments, artikler._views, category.category FROM content_ar INNER JOIN artikler ON content_ar.re_for = artikler.id INNER JOIN category ON artikler.re_cat = category.id INNER JOIN redaktionen ON artikler.re_red = redaktionen.id WHERE content_ar.preview = 1 AND (artikler.title LIKE '%$searchQuery%' OR content LIKE '%$searchQuery%' OR redaktionen.name LIKE '%$searchQuery%' OR category.category LIKE '%$searchQuery%') ORDER BY artikler._added DESC";
    }else{
        if($cat == 'bod'){
            $cat = 'båd';
        }
        $sql = "SELECT artikler.title, LEFT(content_ar.content, 501) AS content, artikler._added, artikler.id, artikler._comments, artikler._views, category.category FROM content_ar INNER JOIN artikler ON content_ar.re_for = artikler.id INNER JOIN category ON artikler.re_cat = category.id WHERE content_ar.preview = 1 && category.category = '$cat' ORDER BY artikler._added DESC LIMIT 3";
    }
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $getIndex[] = $row;
        }
    }
?>