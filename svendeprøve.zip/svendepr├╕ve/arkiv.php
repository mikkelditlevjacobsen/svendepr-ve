<?php
    $site = 5;
    include('./include/header.php');
    if(empty($_GET['page'])){
        $pageid = 1;
    }else{
        $pageid = $_GET['page'];
    }
    echo '
        <script>
            var paginationId = '.$pageid.';
            const jsSite = "arkiv";
        </script>
    ';
    if(!empty($_GET['q'])){
        echo '
            <script>
                var searchQuery = "'.$_GET['q'].'";
            </script>
        ';
    }
?>
        <main class="clearfix">
            <div class="main-cont arkiv-page clearfix col8">
                <h1>SENESTE ARTIKLER</h1>
                <div class="outside-arkiv-article"></div>
                <div class="pages-numbers"></div>
            </div>
            <?php include('./include/aside.php'); ?>
        </main>
        <?php include('./include/footer.php'); ?>