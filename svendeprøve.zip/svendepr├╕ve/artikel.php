<?php
    $site = $_GET['cat'];
    include('./include/header.php');
    echo '
        <script>
            var artikelId = '.$_GET['id'].';
            var artikelCat = "'.$site.'";
            const jsSite = "artikel";
        </script>
    ';
?>
    <main class="clearfix">
        <article class="main-cont clearfix col8">
            <h1></h1>
            <div class="full-article-main clearfix">
                <div class="art-content-inside clearfix">

                </div>
                <div class="writtenby clearfix">
                    <div class="profile-img-article">
                        <img src="" alt="Profil billede">
                    </div>
                    <div class="outside-text-profile">
                        <p class="name-and-role"></p>
                        <p class="bio"></p>
                    </div>
                </div>
            </div>
            <h2 class="comments-h2">KOMMENTARER</h2>
            <p class="no-comments">Ingen kommentarer</p>
            <h2 class="your-comment">Din kommentar</h2>
            <form id="comment" name="comment" action="javascript:void(0)" class="clearfix" onsubmit="commentValidation(this)" autocomplete="on" novalidate>
                <div class="first-input">
                    <p>Dit navn</p>
                    <input type="text" name="name" autocomplete="name">
                </div>
                <div class="sec-input">
                    <p>Dit e-mailadresse</p>
                    <input type="email" name="email" autocomplete="email">
                </div>
                <p>Kommentar</p>
                <textarea name="besked"></textarea>
                <p class="ud-wrong-text"></p>
                <input type="submit" name="go" value="UDFØR">
            </form>
        </article>
        <?php include('./include/aside.php'); ?>
    </main>
<?php include('./include/footer.php'); ?>