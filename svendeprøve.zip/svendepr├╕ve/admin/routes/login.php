<?php
    session_start();
    $username = $_POST['username'];
    $password = $_POST['password'];
    include("../../db/db_con.php");
    $sql = "SELECT redaktionen.id, redaktionen.name, redaktionen.mail, redaktionen.bio, redaktionen.image, category.category, roles.role, redaktionen.username, redaktionen.password FROM redaktionen INNER JOIN category ON redaktionen.re_for = category.id INNER JOIN roles ON redaktionen.role_type = roles.id WHERE redaktionen.username = '$username' && redaktionen.password = '$password'";
    $result = $conn->query( $sql );
    if ( $result->num_rows > 0 ) {
        while ( $row = $result->fetch_assoc() ) {
            $rUsername = $row['username'];
            $rPassword = $row['password'];
            $rName = $row['name'];
            $rCategory = $row['category'];
            $rRole = $row['role'];
            $rId = $row['id'];
        }
    }
    if($username == $rUsername && $password == $rPassword){
        $_SESSION['loggedin'] = $rUsername;
        $_SESSION['name'] = $rName;
        $_SESSION['category'] = $rCategory;
        $_SESSION['role'] = $rRole;
        $_SESSION['id'] = $rId;
        header('Location: ../index');
    }else{
        header('Location: ../login?m=Forkert_login');
    }
    $conn->close();
?>