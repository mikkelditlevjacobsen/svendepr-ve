<?php
    include('../../db/db_con.php');
    include('../routes/getCategory.php');
    echo json_encode($getCategory);
    $conn->close();
?>