<?php
    include('./include/session_head.php');
    include('./include/header.php');
?>
<main>
    
</main>
<?php include('./include/footer.php'); ?>