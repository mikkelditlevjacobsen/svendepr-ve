<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.1/jquery-ui.min.js"></script>
<script src="/svendeprøve/admin/js/global_ajax.js"></script>
<script src="/svendeprøve/admin/js/main.js"></script>
</body>
</html>