<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link type="text/css" rel="stylesheet" href="/svendeprøve/admin/css/main.css">
    <link type="text/css" rel="stylesheet" href="/svendeprøve/css/stand.css">
    <link href="https://fonts.googleapis.com/css?family=Oswald:400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <title>BIL BÅD &amp; BIKE</title>
</head>
<body>
    <header class="clearfix">
        <div class="burger-menu">
            <i class="fas fa-bars"></i>
        </div>
        <div class="user-menu">
            <i class="fas fa-user"></i>
        </div>
    </header>
    <div class="user-manu-open">
        <p><?php echo $name; ?></p>
        <a href="/svendeprøve/admin/routes/logout">Log ud</a>
    </div>
    <div class="side-menu">
        <nav>
            <ul>
                <li>
                    <a href="/svendeprøve/admin/opret_artikel">Opret Artikel</a>
                </li>
            </ul>
        </nav>
    </div>
    <div class="under-header"></div>