<?php
    include('./include/session_head.php');
    include('./include/header.php');
    echo '
        <script>
            var userId = '.$id.';
            var userCat = "'.$category.'";
        </script>
    ';
?>
<script>
    const jsSite = "cr_artikel";
</script>
<main>
    <form id="crartikel" name="crartikel" action="javascript:void(0)" class="clearfix" onsubmit="artikelValidation(this)" novalidate>
        <input type="hidden" name="redaktor" value="<?php echo $id; ?>">
        <select name="category"></select>
        <input type="text" name="title" placeholder="Overskrift på artikel">
    </form>
</main>
<?php include('./include/footer.php'); ?>