<?php echo $_GET['m']; ?>
<form action="/svendeprøve/admin/routes/login" method="POST">
    <input type="text" name="username" placeholder="Brugernavn">
    <input type="password" name="password" placeholder="Kodeord">
    <input type="submit" value="Log ind">
</form>