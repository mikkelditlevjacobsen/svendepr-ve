function getCategory () {
    var dataAfter;
    $.ajax({
        type: "POST",
        url: "/svendeprøve/admin/ajax/getCategory.php",
        success: function(data){
            if(data){
                dataAfter = JSON.parse(data);
                console.log(dataAfter);
                console.log(userCat);
                if(userCat == 'all'){
                    $.each(dataAfter, function(key, value) {
                        $('select[name="category"]').append('<option value="'+value.category+'">'+value.category+'</option>');
                    });
                }else{
                    $.each(dataAfter, function(key, value) {
                        if(userCat == value.category){
                            $('select[name="category"]').append('<option value="'+value.category+'">'+value.category+'</option>');
                        }
                    });
                }
            }else{
                alert('Siden kunne desværre ikke hente den nødvendige data2.');
            }
        },
        error: function (response) {
            console.log(response);
        }
    });
}