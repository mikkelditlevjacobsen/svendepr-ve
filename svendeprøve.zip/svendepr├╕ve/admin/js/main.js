$(function(){
    $('.user-menu').click(function(){
        $('.user-manu-open').toggle();
    });
    $(".burger-menu").click(function() {
        var n = $(".side-menu").css("left");
        if (n == "0px") {
          $(".side-menu").animate({left: "-250px"},300);
        }else {
          $(".side-menu").animate({left: "0px"},300);
        }
    });

    //category
    if(jsSite == 'cr_artikel'){
        getCategory();
    }
    //--
});