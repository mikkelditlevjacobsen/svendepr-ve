<?php 
    $site = 7;
    include('./include/header.php'); 
?>
<script>
    const jsSite = 'redaktionen';
</script>
        <main class="clearfix">
            <div class="main-cont redaktionen-main clearfix col8">
                <h1>REDAKTIONEN</h1>
                <div class="redaktionen-main-after clearfix col12">
                    <h2>Biler</h2>
                    <h2 class="middleh2">Både</h2>
                    <h2>Bike's</h2>
                </div>
            </div>
            <?php include('./include/aside.php'); ?>
        </main>
        <?php include('./include/footer.php'); ?>