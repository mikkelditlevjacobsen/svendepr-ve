<footer class="clearfix">
    <div class="col4">
        <h3>Adresse</h3>
        <p>Magasinet Bil, Båd &amp; Bike</p>
        <p>Marielundvej 46 E</p>
        <p>2730 Herlev</p>
        <p>Denmark</p>
    </div>
    <div class="col4">
        <h3>Kontakt</h3>
        <p>Telefon: +45 7011 5100</p>
        <p>Fax: +45 4485 8925</p>
        <p>E-mail: redaktionen@bbbmag.dk</p>
    </div>
    <div class="col4">
        <h3>Nyhedsbrev</h3>
        <form id="newsletter" name="newsletter" action="javascript:void(0)" class="clearfix" onsubmit="newsletterValidation(this)" autocomplete="on" novalidate>
            <input type="email" name="mail" placeholder="E-mailadresse" autocomplete="email">
            <p class="ud-wrong-text-f"></p>
            <button class="add-newsletter">TILMELD</button>
            <button class="emove-newsletter">FRAMELD</button>
        </form>
    </div>
</footer>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.1/jquery-ui.min.js"></script>
<script src="/svendeprøve/js/global_ajax.js"></script>
<script src="/svendeprøve/js/main.js"></script>
</body>
</html>