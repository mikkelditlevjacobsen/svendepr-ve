<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link type="text/css" rel="stylesheet" href="/svendeprøve/css/main.css">
    <link href="https://fonts.googleapis.com/css?family=Oswald:400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <title>BIL BÅD &amp; BIKE</title>
</head>
<body>
    <div class="wrapper">
        <header class="clearfix">
            <div>
                <a href="/svendeprøve"><img src="/svendeprøve/img/logo.png" alt="BIL BÅDE &amp; BIKE Logo"></a>
            </div>
            <nav>
                <ul>
                    <li><a <?php if($site == 1){ echo 'class="nav-active"'; } ?>href="/svendeprøve"><i class="fa fa-home"></i> FORSIDE</a></li><!--
                    --><li><a <?php if($site == 'bil'){ echo 'class="nav-active"'; } ?>href="/svendeprøve/kategori/bil">BILER</a></li><!--
                    --><li><a <?php if($site == 'bod'){ echo 'class="nav-active"'; } ?>href="/svendeprøve/kategori/bod">BÅDE</a></li><!--
                    --><li><a <?php if($site == 'bikes'){ echo 'class="nav-active"'; } ?>href="/svendeprøve/kategori/bikes">BIKE'S</a></li><!--
                    --><li><a <?php if($site == 5){ echo 'class="nav-active"'; } ?>href="/svendeprøve/arkiv">ARKIVET</a></li><!--
                    --><li><a <?php if($site == 6){ echo 'class="nav-active"'; } ?>href="/svendeprøve/kontakt">KONTAKT</a></li><!--
                    --><li><a <?php if($site == 7){ echo 'class="nav-active"'; } ?>href="/svendeprøve/redaktionen">REDAKTIONEN</a></li>
                </ul>
            </nav>
        </header>
<?php
    if($site != 1){
        $url = explode("/",$_SERVER['REQUEST_URI']);
        echo '<div class="bread-sti"><p><a href="/svendeprøve">Forside&nbsp;&nbsp;</a></p>';
        for($i=2; $i<count($url); $i++){
            if($url[$i] == 'artikel'){
                echo '<p><a href="/svendeprøve/arkiv">/&nbsp;&nbsp;'.$url[$i].'&nbsp;&nbsp;</a></p>';
            }else if($url[$i] == 'bil' || $url[$i] == 'bod' || $url[$i] == 'bikes'){
                echo '<p><a href="/svendeprøve/kategori/'.$url[$i].'">/&nbsp;&nbsp;'.$url[$i].'&nbsp;&nbsp;</a></p>';
            }else{
                echo '<p><a href="/svendeprøve/'.$url[$i].'">/&nbsp;&nbsp;'.$url[$i].'&nbsp;&nbsp;</a></p>';
            }
        }
        echo '</div>';
    }
?>