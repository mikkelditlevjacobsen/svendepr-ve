<aside class="col4 clearfix">
    <form id="search" name="search" action="/svendeprøve/arkiv" class="clearfix" onsubmit="search(this)" novalidate>
        <input type="search" name="q" <?php if(!empty($_GET['q'])) echo 'value="'.$_GET['q'].'"'; else echo 'placeholder="Søg i arkivet ..."' ?>>
        <button type="submit">
            <i class="fas fa-search"></i>
        </button>
    </form>
    <h3>MEST LÆSTE</h3>
    <ol></ol>
    <h3>SPONSOR</h3>
    <div class="spons"></div>
    <p><a href="/svendeprøve/sponsor">Din reklame her?</a></p>
</aside>