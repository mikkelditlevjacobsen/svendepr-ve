const months = {'01':'Januar', '02':'Februar', '03':'Marts', '04':'April', '05':'Maj', '06':'Juni', '07':'Juli', '08':'August', '09':'September', '10':'Oktober', '11':'November', '12':'December'};
function newDateFunc (oldDate) {
    return oldDate.substring(8, 10).replace(/^0+/, '')+'. '+months[oldDate.substring(5, 7)]+' '+oldDate.substring(0, 4)+ ' Kl. '+oldDate.substring(11, 13)+':'+oldDate.substring(14, 16);
}
function getRedaktion () {
    var dataAfter;
    $.ajax({
        type: "POST",
        url: "/svendeprøve/ajax/getRedaktion.php",
        success: function(data){
            if(data){
                dataAfter = JSON.parse(data);
                $.each(dataAfter, function(key, value) {
                    let elementToAppend = `<div class="redaktionen-selv col12 clearfix"><div class="redak-img col2"><img src="/svendeprøve/img/profile/`+value.image+`" alt="Profil billede"></div><div class="redak-txt col10"><h3>`+value.name+`</h3><p><i class="fas fa-envelope"></i> E-mail: `+value.name+`</p><p>`+value.bio+`</p></div></div>
                    `;
                    if(value.re_for == 1){
                        $(elementToAppend).insertAfter('.redaktionen-main h2:first-of-type');
                    }else if(value.re_for == 2){
                        $(elementToAppend).insertAfter('.redaktionen-main h2.middleh2');
                    }else if(value.re_for == 3){
                        $(elementToAppend).insertAfter('.redaktionen-main h2:last-of-type');
                    }
                });
                loading('.redaktionen-main-after', false);
            }else{
                alert('Siden kunne desværre ikke hente den nødvendige data.');
            }
        },
        error: function (response) {
            console.log(response);
        }
    });
}
function getMostViewed (cat = 'none') {
    var dataAfter;
    var newCategory;
    $.ajax({
        type: "POST",
        url: "/svendeprøve/ajax/getMostViewed.php",
        data: { cat: cat },
        success: function(data){
            if(data){
                dataAfter = JSON.parse(data);
                $.each(dataAfter, function(key, value) {
                    if (value.category == 'båd') newCategory = 'bod'; else newCategory = value.category;
                    let elementToAppend = `<li><a href="/svendeprøve/artikel/`+newCategory+`/`+value.id+`">`+value.title+`</a></li>`;
                    $('aside ol').append(elementToAppend);
                });
                loading('aside ol', false);
            }else{
                alert('Siden kunne desværre ikke hente den nødvendige data.');
            }
        },
        error: function (response) {
            console.log(response);
        }
    });
}
function getAds (cat = 'none') {
    var dataAfter;
    $.ajax({
        type: "POST",
        url: "/svendeprøve/ajax/getReklamer.php",
        data: { cat: cat },
        success: function(data){
            if(data){
                dataAfter = JSON.parse(data);
                $.each(dataAfter, function(key, value) {
                    let elementToAppend = `<div><img src="/svendeprøve/img/spons/`+value.ad+`"></div>`;
                    $('aside .spons').append(elementToAppend);
                });
                loading('aside .spons', false);
            }else{
                alert('Siden kunne desværre ikke hente den nødvendige data.');
            }
        },
        error: function (response) {
            console.log(response);
        }
    });
}
function getIndex (cat = 'none', offsetNumber = 0, amountPerSite, searchQuery = '') {
    var dataAfter;
    var newTitle;
    var newContent;
    var newCategory;
    $.ajax({
        type: "POST",
        url: "/svendeprøve/ajax/getIndex.php",
        data: { cat: cat, offsetNumber: offsetNumber, amountPerSite: amountPerSite, searchQuery: searchQuery },
        success: function(data){
            if(data){
                dataAfter = JSON.parse(data);
                if(cat == 'none'){
                    $.each(dataAfter, function(key, value) {
                        if (value.title.length == 29) newTitle = value.title.substring(0, 28)+' ...'; else newTitle = value.title;
                        if (value.content.length == 201) newContent = value.content.substring(0, 200)+' ...'; else newContent = value.content;
                        if (value.category == 'båd') newCategory = 'bod'; else newCategory = value.category;
                        let elementToAppend = `<div class="main-article col6"><h2>`+newTitle+`</h2><span><i class="far fa-clock"></i> `+newDateFunc(value._added)+`</span><span><i class="fas fa-comments"></i> `+value._comments+` KOMMENTARER</span><span><i class="far fa-eye"></i> `+value._views+` VISNINGER</span><p>`+newContent+`</p><span class="tag-span"><i class="fas fa-tag"></i> `+value.category+`</span>  <div class="knap-article"><a href="/svendeprøve/artikel/`+newCategory+`/`+value.id+`">LÆS MERE</a></div></div>`;
                        $('.index-article-inner').append(elementToAppend);
                    });
                }else if(cat == 'arkiv'){
                    getArtikelAmount(amountPerSite);
                    $('.main-article').remove();
                    $.each(dataAfter, function(key, value) {
                        if (value.content.length == 201) newContent = value.content.substring(0, 200)+' ...'; else newContent = value.content;
                        if (value.category == 'båd') newCategory = 'bod'; else newCategory = value.category;
                        let elementToAppend = `
                        <div class="main-article">
                            <h2>`+value.title+`</h2>
                            <span><i class="far fa-clock"></i> `+newDateFunc(value._added)+`</span>
                            <span><i class="fas fa-comments"></i> `+value._comments+` KOMMENTARER</span>
                            <span><i class="far fa-eye"></i> `+value._views+` VISNINGER</span>
                            <p>`+newContent+`</p>
                            <span class="tag-span"><i class="fas fa-tag"></i> `+value.category+`</span>
                            <div class="knap-article"><a href="/svendeprøve/artikel/`+newCategory+`/`+value.id+`">LÆS MERE</a></div>
                        </div>
                        `;
                        $('.outside-arkiv-article').append(elementToAppend);
                    });
                }else if(cat == 'sog'){
                    if(dataAfter == null){
                        $('.outside-arkiv-article').append('<p class="searc-resultat">Din søgning på <span>'+searchQuery+'</span> returnerede <span>0</span> artikler</p>');
                    }else{
                        $('.main-article').remove();
                        $('.outside-arkiv-article').append('<p class="searc-resultat">Din søgning på <span>'+searchQuery+'</span> returnerede <span>'+dataAfter.length+'</span> artikler</p>');
                        $.each(dataAfter, function(key, value) {
                            if (value.content.length == 201) newContent = value.content.substring(0, 200)+' ...'; else newContent = value.content;
                            if (value.category == 'båd') newCategory = 'bod'; else newCategory = value.category;
                            let elementToAppend = `
                            <div class="main-article">
                                <h2>`+value.title+`</h2>
                                <span><i class="far fa-clock"></i> `+newDateFunc(value._added)+`</span>
                                <span><i class="fas fa-comments"></i> `+value._comments+` KOMMENTARER</span>
                                <span><i class="far fa-eye"></i> `+value._views+` VISNINGER</span>
                                <p>`+newContent+`</p>
                                <span class="tag-span"><i class="fas fa-tag"></i> `+value.category+`</span>
                                <div class="knap-article"><a href="/svendeprøve/artikel/`+newCategory+`/`+value.id+`">LÆS MERE</a></div>
                            </div>
                            `;
                            $('.outside-arkiv-article').append(elementToAppend);
                        });
                    }
                    // if(dataAfter.length == 0){
                    //     console.log('0');
                    // }else{
                    //     $('.main-article').remove();
                    //     $('.outside-arkiv-article').append('<p class="searc-resultat">Din søgning på <span>'+searchQuery+'</span> returnerede <span>'+dataAfter.length+'</span> artikler</p>');
                    //     $.each(dataAfter, function(key, value) {
                    //         if (value.content.length == 201) newContent = value.content.substring(0, 200)+' ...'; else newContent = value.content;
                    //         if (value.category == 'båd') newCategory = 'bod'; else newCategory = value.category;
                    //         let elementToAppend = `
                    //         <div class="main-article">
                    //             <h2>`+value.title+`</h2>
                    //             <span><i class="far fa-clock"></i> `+newDateFunc(value._added)+`</span>
                    //             <span><i class="fas fa-comments"></i> `+value._comments+` KOMMENTARER</span>
                    //             <span><i class="far fa-eye"></i> `+value._views+` VISNINGER</span>
                    //             <p>`+newContent+`</p>
                    //             <span class="tag-span"><i class="fas fa-tag"></i> `+value.category+`</span>
                    //             <div class="knap-article"><a href="/svendeprøve/artikel/`+newCategory+`/`+value.id+`">LÆS MERE</a></div>
                    //         </div>
                    //         `;
                    //         $('.outside-arkiv-article').append(elementToAppend);
                    //     });
                    // }
                }else{
                    $.each(dataAfter, function(key, value) {
                        if (value.content.length == 501) newContent = value.content.substring(0, 500)+' ...'; else newContent = value.content;
                        if (value.category == 'båd') newCategory = 'bod'; else newCategory = value.category;
                        let elementToAppend = `<div class="main-article onkategorisite"><h2>`+value.title+`</h2><span><i class="far fa-clock"></i> `+newDateFunc(value._added)+`</span><span><i class="fas fa-comments"></i> `+value._comments+` KOMMENTARER</span><span><i class="far fa-eye"></i> `+value._views+` VISNINGER</span><p>`+newContent+`</p><div class="onskatsitebut knap-article"><a href="/svendeprøve/artikel/`+newCategory+`/`+value.id+`">LÆS MERE</a></div></div>`;
                        $('.kategori-inside').append(elementToAppend);
                    });
                }
                if(cat == 'none'){
                    loading('.index-article-inner', false);
                }else if(cat == 'arkiv' || cat == 'sog'){
                    loading('.outside-arkiv-article', false);
                }else{
                    loading('.kategori-inside', false);
                }
            }else{
                alert('Siden kunne desværre ikke hente den nødvendige data.');
            }
        },
        error: function (response) {
            console.log(response);
        }
    });
}
function updateViews (id) {
    $.ajax({
        type: "POST",
        url: "/svendeprøve/ajax/updateViews.php",
        data: { id: id },
        success: function(data){
            getFullArticle(id);
            getComments(id);
        },
        error: function (response) {
            console.log(response);
        }
    });
}
function getFullArticle (id) {
    var dataAfter;
    $.ajax({
        type: "POST",
        url: "/svendeprøve/ajax/getFullArticle.php",
        data: { id: id },
        success: function(data){
            if(data){
                dataAfter = JSON.parse(data);
                getRestArticle(dataAfter[0].id, dataAfter[0]._order.split(''));
                $('.main-cont h1').text(dataAfter[0].title);
                $('.full-article-main').prepend('<span><i class="far fa-clock"></i> '+newDateFunc(dataAfter[0]._added)+'</span><span><i class="fas fa-comments"></i> '+dataAfter[0]._comments+' KOMMENTARER</span><span><i class="far fa-eye"></i> '+dataAfter[0]._views+' VISNINGER</span>');
                $('.writtenby img').attr('src', '/svendeprøve/img/profile/'+dataAfter[0].image);
                $('.name-and-role').html('af '+dataAfter[0].name+' <span>Redaktør</span>');
                $('.bio').text(dataAfter[0].bio);
            }else{
                alert('Siden kunne desværre ikke hente den nødvendige data2.');
            }
        },
        error: function (response) {
            console.log(response);
        }
    });
}
function getRestArticle (id, order) {
    var dataAfter;
    $.ajax({
        type: "POST",
        url: "/svendeprøve/ajax/getRestArticle.php",
        data: { id: id },
        success: function(data){
            if(data){
                dataAfter = JSON.parse(data);
                $.each(order, function(key, value) {
                    if(value == 'i'){
                        $('.art-content-inside').append('<p class="intro-tekst">'+dataAfter[key].content.replace(/\n/g,"<br>")+'</p>');
                    }else if(value == 'b'){
                        $('.art-content-inside').append('<p>'+dataAfter[key].content.replace(/\n/g,"<br>")+'</p>');
                    }else if(value == 'h'){
                        $('.art-content-inside').append('<h3>'+dataAfter[key].content.replace(/\n/g,"<br>")+'</h3>');
                    }else if(value == 't'){
                        $('.art-content-inside').append('<table>'+dataAfter[key].content+'</table>');
                    }else if(value == 'p'){
                        $('.art-content-inside').append('<div class="procons-article">'+dataAfter[key].content+'</div>');
                        $('.procons-article .pro').prepend('<span>+</span>');
                        $('.procons-article .cons').prepend('<span>-</span>');
                    }else if(value == 'l'){
                        $('.art-content-inside').append('<ol>'+dataAfter[key].content+'</ol>');
                    }
                });
                loading('.full-article-main', false);
            }else{
                alert('Siden kunne desværre ikke hente den nødvendige data2.');
            }
        },
        error: function (response) {
            console.log(response);
        }
    });
}
function getComments (id) {
    var dataAfter;
    $.ajax({
        type: "POST",
        url: "/svendeprøve/ajax/getComments.php",
        data: { id: id },
        success: function(data){
            if(data){
                $('.comment').remove();
                dataAfter = JSON.parse(data);
                $.each(dataAfter, function(key, value) {
                    $('.no-comments').remove();
                    let elementToAppend = `
                    <div class="comment">
                        <div class="commenticon"><i class="fas fa-comment"></i></div>
                        <div class="commenttext">
                            <p class="commentname">`+value.name+`</p>
                            <span><i class="far fa-clock"></i> `+newDateFunc(value._added)+`</span>
                            <p class="comment-this-comment">`+value._comment+`</p>
                        </div>
                    </div>
                    `;
                    $(elementToAppend).insertAfter('.comments-h2');
                });
            }else{
                alert('Siden kunne desværre ikke hente den nødvendige data2.');
            }
        },
        error: function (response) {
            console.log(response);
        }
    });
}
function insertComment (id, name, mail, comment) {
    $.ajax({
        type: "POST",
        url: "/svendeprøve/ajax/insertComment.php",
        data: { id: id, name: name, mail: mail, comment: comment },
        success: function(data){
            getComments(id);
            loading('form#comment', false);
            $('form#comment > *:not(.loading-icon)').hide();
            $('form#comment').append('<div class="ud-succes-comment"><p><i class="fa fa-check-circle"></i></p><p>Din kommentar er blevet oprettet.</p><p>Skriv en ny</p></div>');
        },
        error: function (response) {
            console.log(response);
        }
    });
}
function insertNewsletter (mail) {
    $.ajax({
        type: "POST",
        url: "/svendeprøve/ajax/getNewsletterMail.php",
        data: { mail: mail },
        success: function(data){
            if(data == 'true'){
                $.ajax({
                    type: "POST",
                    url: "/svendeprøve/ajax/deleteNewsletter.php",
                    data: { mail: mail },
                    success: function(data){
                        $('form#newsletter > *:not(.loading-icon)').hide();
                        if(data == 'true'){
                            $('form#newsletter').append('<div class="ud-succes-newsletter"><p><i class="fa fa-check-circle"></i></p><p>Din mail er blevet slettet.</p><p>Tilmeld en anden mail</p></div>');
                        }else{
                            $('form#newsletter').append('<div class="ud-succes-newsletter"><p><i class="fa fa-times-circle"></i></p><p>Der skete en fejl.</p><p>Prøv igen</p></div>');
                        }
                    },
                    error: function (response) {
                        console.log(response);
                    }
                });
            }else{
                $.ajax({
                    type: "POST",
                    url: "/svendeprøve/ajax/insertNewsletter.php",
                    data: { mail: mail },
                    success: function(data){
                        $('form#newsletter > *:not(.loading-icon)').hide();
                        if(data == 'true'){
                            $('form#newsletter').append('<div class="ud-succes-newsletter"><p><i class="fa fa-check-circle"></i></p><p>Vi har modtaget din e-mail.</p><p>Tilmeld en anden mail</p></div>');
                        }else{
                            $('form#newsletter').append('<div class="ud-succes-newsletter"><p><i class="fa fa-times-circle"></i></p><p>Der skete en fejl.</p><p>Prøv igen</p></div>');
                        }
                    },
                    error: function (response) {
                        console.log(response);
                    }
                });
            }
        },
        error: function (response) {
            console.log(response);
        }
    });
}
function getNewsletterMail (mail) {
    if(mail == ''){
        $('.emove-newsletter').removeClass('cannot-select').attr('disabled', false);
        $('.add-newsletter').removeClass('cannot-select').attr('disabled', false);
    }else{
        $.ajax({
            type: "POST",
            url: "/svendeprøve/ajax/getNewsletterMail.php",
            data: { mail: mail },
            success: function(data){
                if(data == 'true'){
                    $('.add-newsletter').addClass('cannot-select').attr('disabled', true);
                    $('.emove-newsletter').removeClass('cannot-select').attr('disabled', false);
                }else{
                    $('.emove-newsletter').addClass('cannot-select').attr('disabled', true);
                    $('.add-newsletter').removeClass('cannot-select').attr('disabled', false);
                }
            },
            error: function (response) {
                console.log(response);
            }
        });
    }
}
function getArtikelAmount (amountPerSite) {
    $.ajax({
        type: "POST",
        url: "/svendeprøve/ajax/getArtikelAmount.php",
        success: function(data){
            let siteNumbers = Math.ceil(data / amountPerSite);
            if(paginationId == 0) paginationId = 1;
            if(siteNumbers != 1){
                for(i=1; i<=siteNumbers; i++){
                    if(i == paginationId){
                        $('.pages-numbers').append('<a class="active-page-link" href="/svendeprøve/arkiv/'+i+'">'+i+'</a>');
                    }else{
                        $('.pages-numbers').append('<a href="/svendeprøve/arkiv/'+i+'">'+i+'</a>');
                    }
                }
            }
        },
        error: function (response) {
            console.log(response);
        }
    });
}
function sendMail (name, mail, emne, besked) {
    $.ajax({
        type: "POST",
        url: "/svendeprøve/ajax/sendMail.php",
        data: { name: name, mail: mail, emne: emne, besked: besked },
        success: function(data){
            $('form#kontaktForm > *:not(.loading-icon)').hide();
            if(data == 'true'){
                $('form#kontaktForm').append('<div class="ud-succes-kontaktform"><p><i class="fa fa-check-circle"></i></p><p>Din besked er blevet sendt.</p><p>Send en anden besked</p></div>');
            }else{
                $('form#kontaktForm').append('<div class="ud-succes-kontaktform"><p><i class="fa fa-times-circle"></i></p><p>Der skete en fejl.</p><p>Prøv igen</p></div>');
            }
            loading('form#kontaktForm', false);
        },
        error: function (response) {
            console.log(response);
        }
    });
}