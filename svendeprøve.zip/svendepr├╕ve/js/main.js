function loading(i,l){l?($(i+" .loading-icon").remove(),$(i).append('<div class="clearfix loading-icon"><img src="/svendeprøve/img/loading.gif"></div>')):$(i+" .loading-icon").remove();}
var commentValidation;
var newsletterValidation;
var kontaktValidation;
$(function() {
    //ASIDE
    loading('aside ol', true);
    loading('aside .spons', true);
    if (typeof artikelCat == 'undefined') {
        getMostViewed();
        getAds();
    }else{
        getMostViewed(artikelCat);
        getAds(artikelCat);
    }
    //--

    //index
    if (jsSite == "index") {
        loading('.index-article-inner', true);
        getIndex();
    }
    //--

    //artikel
    if(jsSite == "artikel"){
        loading('.full-article-main', true);
        updateViews(artikelId);
    }
    //--

    //redaktionen
    if (jsSite == "redaktionen") {
        loading('.redaktionen-main-after', true);
        getRedaktion();
    }
    //--

    //comment validation
    commentValidation = function(form) {
        let hasNumber = /\d/;
        let wrong = $(".ud-wrong-text");
        var atpos = form.email.value.indexOf("@");
        var dotpos = form.email.value.lastIndexOf(".");
        wrong.slideUp(200);
        function wrongText(text) {
            wrong.text(text);
            wrong.slideDown(200);
        }
        if (!form.name.value.trim()) {
            form.name.focus();
            form.name.select();
            wrongText("Angiv venligst dit navn");
            return false;
        }
        if (hasNumber.test(form.name.value)) {
            form.name.focus();
            form.name.select();
            wrongText("Dit navn kan ikke indeholde tal");
            return false;
        }
        if (!form.email.value.trim()) {
            form.email.focus();
            form.email.select();
            wrongText("Angiv venligst din e-mail");
            return false;
        }
        if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= form.email.value.length) {
            form.email.focus();
            form.email.select();
            wrongText("Angiv venligst en gyldig e-mail");
            return false;
        }
        if (!form.besked.value.trim()) {
            form.besked.focus();
            form.besked.select();
            wrongText("Udfyld venligst kommentar feltet");
            return false;
        }
        if (form.besked.value.length > 200) {
            form.besked.focus();
            form.besked.select();
            wrongText("Kommentaren må max være 200 tegn. Din kommentar fylder "+form.besked.value.length+" tegn");
            return false;
        }
        loading('form#comment', true);
        insertComment(artikelId, form.name.value, form.email.value, form.besked.value);
    }
    $(document).on('click', '.ud-succes-comment p:last-of-type', function(){
        $('.ud-succes-comment').remove();
        $('form#comment').trigger("reset");
        $('form#comment > *:not(.loading-icon)').show();
    });
    //--

    //kategori
    if(jsSite == "kategori"){
        loading('.kategori-inside', true);
        getIndex(artikelCat);
    }
    //--

    //newsletter validation
    newsletterValidation = function(form) {
        let wrong = $(".ud-wrong-text-f");
        var atpos = form.mail.value.indexOf("@");
        var dotpos = form.mail.value.lastIndexOf(".");
        wrong.slideUp(200);
        function wrongText(text) {
            wrong.text(text);
            wrong.slideDown(200);
        }
        if (!form.mail.value.trim()) {
            form.mail.focus();
            form.mail.select();
            wrongText("Angiv venligst din e-mail");
            return false;
        }
        if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= form.mail.value.length) {
            form.mail.focus();
            form.mail.select();
            wrongText("Angiv venligst en gyldig e-mail");
            return false;
        }
        insertNewsletter(form.mail.value);
    }
    $('#newsletter input').keyup(function(){
        getNewsletterMail(this.value);
    });
    $(document).on('click', '.ud-succes-newsletter p:last-of-type', function(){
        $('.ud-succes-newsletter').remove();
        $('form#newsletter').trigger("reset");
        $('form#newsletter > *:not(.loading-icon)').show();
    });
    //--

    //arkiv
    if(jsSite == 'arkiv'){
        const amountPerSite = 5;
        loading('.outside-arkiv-article', true);
        if (typeof searchQuery !== 'undefined') {
            getIndex('sog', 0, 0, searchQuery);
        }else{
            getIndex('arkiv', (paginationId-1)*amountPerSite, amountPerSite);
        }
    }
    //--

    //kontakt validering
    kontaktValidation = function(form) {
        let hasNumber = /\d/;
        let wrong = $(".ud-wrong-text");
        var atpos = form.email.value.indexOf("@");
        var dotpos = form.email.value.lastIndexOf(".");
        wrong.slideUp(200);
        function wrongText(text) {
            wrong.text(text);
            wrong.slideDown(200);
        }
        if (!form.name.value.trim()) {
            form.name.focus();
            form.name.select();
            wrongText("Angiv venligst dit navn");
            return false;
        }
        if (hasNumber.test(form.name.value)) {
            form.name.focus();
            form.name.select();
            wrongText("Dit navn kan ikke indeholde tal");
            return false;
        }
        if (!form.email.value.trim()) {
            form.email.focus();
            form.email.select();
            wrongText("Angiv venligst din e-mail");
            return false;
        }
        if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= form.email.value.length) {
            form.email.focus();
            form.email.select();
            wrongText("Angiv venligst en gyldig e-mail");
            return false;
        }
        if (!form.emne.value.trim()) {
            form.emne.focus();
            form.emne.select();
            wrongText("Udfyld venligst emne feltet");
            return false;
        }
        if (!form.besked.value.trim()) {
            form.besked.focus();
            form.besked.select();
            wrongText("Udfyld venligst besked feltet");
            return false;
        }
        loading('form#kontaktForm', true);
        sendMail(form.name.value, form.email.value, form.emne.value, form.besked.value);
    }
    $(document).on('click', '.ud-succes-kontaktform p:last-of-type', function(){
        $('.ud-succes-kontaktform').remove();
        $('form#kontaktForm').trigger("reset");
        $('form#kontaktForm > *:not(.loading-icon)').show();
    });
    //--
});
